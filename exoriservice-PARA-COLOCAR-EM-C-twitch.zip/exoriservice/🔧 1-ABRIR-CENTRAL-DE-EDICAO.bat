@echo off
chcp 65001 >nul
cd /d "%~dp0"
call servidor\1-ABRIR-CENTRAL.bat
