@echo off
chcp 65001 >nul
title Exoriservice — Atualizar URLs para localhost

echo.
echo  ============================================================
echo    ATUALIZAR URLs DO OBS PARA http://localhost:8765/
echo  ============================================================
echo.
echo  Este script troca todas as fontes de navegador do OBS de
echo  arquivo local (file:// ou C:\...) para http://localhost:8765/.
echo.
echo  ❗ O OBS deve estar FECHADO antes de rodar isto.
echo.
echo  Rode APENAS UMA VEZ depois de instalar o pacote.
echo.
pause
echo.

REM %~dp0 = C:\twitch\exoriservice\servidor\
REM A raiz do pacote é a pasta ACIMA (..)
cd /d "%~dp0.."
set "RAIZ=%CD%"
set "JSON=%RAIZ%\obs\exoriservice-cenas.json"

if not exist "%JSON%" (
    echo ERRO: Nao encontrei %JSON%
    echo Execute este arquivo a partir de C:\twitch\exoriservice\servidor\
    pause
    exit /b 1
)

echo  Fazendo backup do JSON atual...
copy /Y "%JSON%" "%JSON%.bak-file" >nul
echo  [OK] Backup salvo em %JSON%.bak-file
echo.

echo  Convertendo URLs para localhost:8765 ...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0atualizar-urls.ps1" -JSONPath "%JSON%"

echo.
echo  ============================================================
echo   PRONTO!
echo  ============================================================
echo.
echo  Agora sempre que for usar:
echo    1. Dê duplo-clique em 🔧 1-ABRIR-CENTRAL-DE-EDICAO.bat
echo       (na pasta C:\twitch\exoriservice\)
echo    2. Depois abra o OBS.
echo    3. A Central abre automaticamente no Chrome/Edge.
echo       Edite lá que o OBS atualiza em tempo real.
echo.
echo  Para VOLTAR ao modo arquivo local (sem precisar do servidor):
echo    renomeie %JSON%.bak-file para %JSON%
echo.
pause
