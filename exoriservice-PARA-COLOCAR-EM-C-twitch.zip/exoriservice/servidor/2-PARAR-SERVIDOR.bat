@echo off
chcp 65001 >nul
title Exoriservice — Parar servidor

echo.
echo  Parando servidor local do Exoriservice...
echo.

powershell.exe -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*servidor.ps1*' } | ForEach-Object { Write-Host ('Encerrando PID ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force }"

echo.
echo  [OK] Servidor encerrado.
timeout /t 2 >nul
