@echo off
chcp 65001 >nul
title Exoriservice — Servidor Local

echo.
echo  ================================================
echo    EXORISERVICE — Iniciando servidor local...
echo  ================================================
echo.

REM %~dp0 = pasta onde este .bat está (= C:\twitch\exoriservice\servidor\)
cd /d "%~dp0"

where powershell >nul 2>&1
if errorlevel 1 (
    echo ERRO: PowerShell nao encontrado.
    pause
    exit /b 1
)

REM servidor.ps1 está na MESMA pasta deste .bat
start "Exoriservice — Servidor Local (NAO FECHAR)" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor.ps1"

timeout /t 3 /nobreak >nul

echo.
echo  [OK] Servidor iniciado em http://localhost:8765/
echo  Abrindo Central no navegador...
echo.

start "" "http://localhost:8765/overlay/live-editor.html"
exit /b 0
