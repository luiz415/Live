param([string]$JSONPath)

$ErrorActionPreference='Stop'

Write-Host "  Lendo $JSONPath ..."
$raw = [IO.File]::ReadAllText($JSONPath, [Text.Encoding]::UTF8)
$j = $raw | ConvertFrom-Json -Depth 100

$contador=0
$baseHttp = "http://localhost:8765/"

foreach ($src in $j.sources) {
    if ($src.id -ne 'browser_source') { continue }
    $st = $src.settings
    if (-not $st) { continue }

    $htmlRel = $null

    # Caso 1: is_local_file=true com campo local_file
    if ($st.is_local_file -and $st.local_file) {
        $lf = $st.local_file -replace '\\','/'
        # Extrair o caminho relativo depois de exoriservice/
        if ($lf -match 'exoriservice/(?<rel>.+)$') {
            $htmlRel = $Matches.rel
        } elseif ($lf -match '^[Cc]:/twitch/exoriservice/(?<rel>.+)$') {
            $htmlRel = $Matches.rel
        }
    }

    # Caso 2: url file:///...
    if ((-not $htmlRel) -and $st.url -and $st.url -match '^file:///') {
        $u = $st.url -replace '\\','/'
        if ($u -match 'exoriservice/(?<rel>.+)$') {
            $htmlRel = $Matches.rel
        } elseif ($u -match '^file:///[Cc]:/twitch/exoriservice/(?<rel>.+)$') {
            $htmlRel = $Matches.rel
        }
        # Remover query string (?t=10) do final, se houver
        if ($htmlRel -and $htmlRel -match '^(?<p>[^?]+)\?') {
            $htmlRel = $Matches.p
        }
    }

    if ($htmlRel) {
        # Normalizar barras
        $htmlRel = $htmlRel -replace '\\','/'
        $novaUrl = $baseHttp + $htmlRel
        $st.url = $novaUrl
        $st.is_local_file = $false
        # Remover local_file (pode ficar vazio ou nulo)
        $st.PSObject.Properties.Remove('local_file')
        $contador++
        Write-Host ("  [{0,2}] {1,-50s} -> {2}" -f $contador, $src.name, $novaUrl)
    }
}

Write-Host ""
Write-Host "  Total de fontes atualizadas: $contador" -ForegroundColor Green

# Converter de volta para JSON
$saida = $j | ConvertTo-Json -Depth 100
[IO.File]::WriteAllText($JSONPath, $saida, [Text.Encoding]::UTF8)
