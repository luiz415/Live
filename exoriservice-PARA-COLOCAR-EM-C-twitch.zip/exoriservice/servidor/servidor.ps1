# ============================================================
#  Servidor HTTP local simples para o Exoriservice Overlay
#  Não precisa instalar nada — usa apenas PowerShell nativo.
#  Roda em http://localhost:8765/
# ============================================================

$ErrorActionPreference = "Continue"
$PORTA = 8765
# servidor.ps1 está em servidor\servidor.ps1 — raiz = pasta pai da pasta servidor\
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Definition
$RAIZ = Split-Path -Parent $SCRIPT_DIR
# RAIZ = C:\twitch\exoriservice\  (pasta do pacote)

$MIMES = @{
  ".html" = "text/html; charset=utf-8"
  ".htm"  = "text/html; charset=utf-8"
  ".css"  = "text/css; charset=utf-8"
  ".js"   = "application/javascript; charset=utf-8"
  ".json" = "application/json; charset=utf-8"
  ".png"  = "image/png"
  ".jpg"  = "image/jpeg"
  ".jpeg" = "image/jpeg"
  ".gif"  = "image/gif"
  ".webp" = "image/webp"
  ".svg"  = "image/svg+xml"
  ".webm" = "video/webm"
  ".mp4"  = "video/mp4"
  ".mp3"  = "audio/mpeg"
  ".wav"  = "audio/wav"
  ".ogg"  = "audio/ogg"
  ".ttf"  = "font/ttf"
  ".otf"  = "font/otf"
  ".woff" = "font/woff"
  ".woff2"= "font/woff2"
  ".ico"  = "image/x-icon"
  ".txt"  = "text/plain; charset=utf-8"
  ".map"  = "application/json"
}

function Get-Mime($ext) {
  if ($MIMES.ContainsKey($ext.ToLower())) { return $MIMES[$ext.ToLower()] }
  return "application/octet-stream"
}

function Resolve-PathSafe($base, $rel) {
  # Previne directory traversal
  $baseFull = [System.IO.Path]::GetFullPath($base)
  $target   = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($baseFull, $rel.TrimStart('/').Replace('/', '\')))
  if (-not $target.StartsWith($baseFull)) { return $null }
  return $target
}

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  EXORISERVICE — Servidor Local" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Pasta raiz : $RAIZ" -ForegroundColor Gray
Write-Host "  URL local  : http://localhost:$PORTA/" -ForegroundColor Green
Write-Host "  Central    : http://localhost:$PORTA/overlay/live-editor.html" -ForegroundColor Green
Write-Host ""
Write-Host "  Deixe esta janela ABERTA enquanto estiver ao vivo." -ForegroundColor Yellow
Write-Host "  Para parar: feche esta janela ou aperte Ctrl+C." -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$PORTA/")
try {
  $listener.Start()
} catch {
  Write-Host "ERRO: Não consegui usar a porta $PORTA." -ForegroundColor Red
  Write-Host "Talvez já exista outra instância rodando." -ForegroundColor Red
  Write-Host ""
  Read-Host "Pressione ENTER para sair"
  exit 1
}

Write-Host "[OK] Servidor rodando. Aguardando requisições..." -ForegroundColor Green
Write-Host ""

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $req = $ctx.Request
    $res = $ctx.Response

    $rawPath = $req.Url.AbsolutePath
    if ($rawPath -eq "/") { $rawPath = "/overlay/live-editor.html" }

    $path = Resolve-PathSafe $RAIZ $rawPath

    $status = 200
    $body   = $null

    if ($null -eq $path -or -not (Test-Path $path)) {
      $status = 404
      $body   = [System.Text.Encoding]::UTF8.GetBytes("<h1>404 - Arquivo não encontrado</h1><p>$rawPath</p>")
    } elseif ((Get-Item $path).PSIsContainer) {
      $status = 403
      $body   = [System.Text.Encoding]::UTF8.GetBytes("<h1>403</h1>")
    } else {
      $ext = [System.IO.Path]::GetExtension($path)
      $mime = Get-Mime $ext
      $res.ContentType = $mime
      try {
        $bytes = [System.IO.File]::ReadAllBytes($path)
        $body = $bytes
      } catch {
        $status = 500
        $body = [System.Text.Encoding]::UTF8.GetBytes("<h1>500</h1><pre>$_</pre>")
      }
    }

    $res.StatusCode = $status
    if ($body) {
      $res.ContentLength64 = $body.Length
      $res.OutputStream.Write($body, 0, $body.Length)
    }
    $res.OutputStream.Close()

    Write-Host ("[{0}] {1} {2}" -f (Get-Date -Format "HH:mm:ss"), $status, $rawPath) -ForegroundColor $(if ($status -eq 200) {"Gray"} else {"Red"})
  }
} finally {
  $listener.Stop()
  Write-Host ""
  Write-Host "[OK] Servidor encerrado." -ForegroundColor Yellow
}
