@echo off
chcp 65001 >nul
cd /d "%~dp0"
call servidor\3-ATUALIZAR-URLs-OBS-PARA-LOCALHOST.bat
