@echo off
chcp 65001 >nul
cd /d "%~dp0"
call servidor\2-PARAR-SERVIDOR.bat
